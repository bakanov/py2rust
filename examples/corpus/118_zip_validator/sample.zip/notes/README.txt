Network archive manifest
