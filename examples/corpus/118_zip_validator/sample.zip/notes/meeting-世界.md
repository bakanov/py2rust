**Saved** message with an attachment.
